package tracker;

public class MultipleCheckInException extends Exception
{
    public MultipleCheckInException(String message) 
    {
        super(message);
    }
}
