package tracker;

public class MissingCheckInException extends Exception
{
    
    public MissingCheckInException(String message) 
    {
        super(message);
    }
}
