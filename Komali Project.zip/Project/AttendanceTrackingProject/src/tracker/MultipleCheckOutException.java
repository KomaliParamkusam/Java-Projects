package tracker;

public class MultipleCheckOutException extends Exception
{
    public MultipleCheckOutException(String message) 
    {
        super(message);
    }
}
