package Week_4.BehavioralPatterns.command;

interface Command 
{
    void execute();
}
