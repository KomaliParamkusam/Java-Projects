package Week_4.BehavioralPatterns.observer;

interface Observer 
{
    void upload();
    void suscribeChannel(Channel sub);
}
