package Week_4.BehavioralPatterns.iterator;

public interface SongIterator 
{
    boolean hasNext();
    Song next();

}
