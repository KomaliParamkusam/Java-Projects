package Week_4.BehavioralPatterns.interpreter;

interface Expression 
{
    int interpreter();
}
