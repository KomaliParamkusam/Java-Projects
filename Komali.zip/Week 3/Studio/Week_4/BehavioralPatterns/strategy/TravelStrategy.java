package Week_4.BehavioralPatterns.strategy;

interface TravelStrategy 
{
    void travel(String source,String destination);
}
