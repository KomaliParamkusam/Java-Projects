package facade;

public class Subtitles 
{
    public void settings()
    {
        System.out.println("""
                              Subtitles enable/disable
                              * Enable 
                              * Disable """);
    }
    public void languageSelection()
    {
        System.out.println("""
                                Select the language
                                * Telugu
                                * Hindi
                                * English """);

    }
    

}
