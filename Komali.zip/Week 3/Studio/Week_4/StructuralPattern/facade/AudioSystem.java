package facade;

public class AudioSystem 
{
    public void audioOn()
    {
        System.out.println("Audio is turned on");
    }
    public void setVolume()
    {
        System.out.println("Set the volume high/low");
    }
    public void audioOff()
    {
        System.out.println("Audio is turned off");
    }
}
