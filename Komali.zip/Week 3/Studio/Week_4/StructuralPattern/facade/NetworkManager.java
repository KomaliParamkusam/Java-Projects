package facade;

public class NetworkManager 
{
    public void connect()
    {
        System.out.println("Connecting to server");
    }
    public void buffer()
    {
        System.out.println("Video Buffering..........");
    }
}
