package bridge;

public class Bow implements Weapons
{
    @Override
    public void attack() 
    {
       System.out.println("Attacking the enemies using Bow");
    }
}
