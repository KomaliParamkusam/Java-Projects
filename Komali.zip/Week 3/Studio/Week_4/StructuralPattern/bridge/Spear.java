package bridge;

public class Spear implements Weapons
{
    @Override
    public void attack() 
    {
       System.out.println("Attacking the enemies using Spear");
    }
}
