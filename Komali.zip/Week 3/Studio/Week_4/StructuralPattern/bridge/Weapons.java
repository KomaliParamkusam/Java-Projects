package bridge;

interface Weapons
{
    void attack();
}
