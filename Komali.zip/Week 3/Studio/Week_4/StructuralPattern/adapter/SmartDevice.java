

interface SmartDevice 
{
    void turnOn();
}
