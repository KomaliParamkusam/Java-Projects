

public class OldFan 
{
    public void startFan()
    {
        System.out.println("Fan is started rotating");
    }
}
