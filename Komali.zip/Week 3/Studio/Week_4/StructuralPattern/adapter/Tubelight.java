public class Tubelight 
{
    public void glow()
    {
        System.out.println("Light is glowing");
    }
}
