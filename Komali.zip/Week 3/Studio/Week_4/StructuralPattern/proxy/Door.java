package proxy;

interface Door 
{
    void open();
}
