package decorator;
interface Sofa 
{
    double getPrice();
    String getDescription();
}
