package composite;

public interface FileSystem 
{
    void showStructure();
}

