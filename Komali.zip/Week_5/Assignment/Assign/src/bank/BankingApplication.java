package bank;

import java.util.Scanner;

public class BankingApplication extends Thread
{
    void homepage()
    {
        Scanner sc=new Scanner(System.in); 
        System.out.println("         WELCOME TO BANKING SYSTEM           ");
        
        System.out.println("-------------------------------------------");                
        System.out.println();     
        System.out.println("[NEW USER]  1.Register ");
        System.out.println("[ALREADY AN USER]   2.Login");
        System.out.println("3. Exit");
        System.out.println();
        System.out.println("-------------------------------------------");  
        int choice=sc.nextInt();
        BankService service=new BankService();
        if(choice==1)
        {
            service.registerUser();
        }
        else if(choice==2)
        {
            service.loginholder();
        }
        else
        {
            System.out.println(".....Exited.....");
        }
    }
    
    public static void main(String[] args) throws InterruptedException
    {
        BankingApplication app=new BankingApplication();
        app.homepage();
        

                                                                                        
    }
}
 
