
public class CourseManagementSystem 
{
    public static void main(String[] args) 
    {
        AdminCourse admin = new AdminCourse();
        admin.loginSystem();
    }
}
