class JavaVersionExample
{
    public static void main(String[] args)
    {
        var a=10;
        System.out.println(((Object)a).getClass().getName());
    }
}