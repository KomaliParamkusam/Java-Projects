import java.io.*;
import java.util.*;
class User implements Serializable
{
    private String Uname;
    private String Gender;
    private int Uage;
    boolean isEligible;
    User(){}
    public User(String Gender, int Uage, String Uname) 
    {
        this.Gender = Gender;
        this.Uage = Uage;
        this.Uname = Uname;
    }
    public void display()
    {
        System.out.println("Name: "+Uname+" Gender: "+Gender+" Age: "+Uage+" Vote Eligibility: "+isEligible);
    }
    public void checkEligibility() 
    {
        isEligible = Uage >= 18;
    }
    public void Serialization(List<User> UList) throws FileNotFoundException,IOException
    {
        
        FileOutputStream fout=new FileOutputStream("User.txt");
        ObjectOutputStream out=new ObjectOutputStream(fout);
        out.writeObject(UList);
        System.out.println("Successfully Serialized");
        fout.close();
        out.close(); 
       
    }
    public List<User> Deserialization() throws FileNotFoundException,IOException, ClassNotFoundException
    {
        
            FileInputStream fin=new FileInputStream("User.txt");
            ObjectInputStream oin=new ObjectInputStream(fin);
            List<User> Dlist=(List<User>)oin.readObject();
            System.out.println("Successfully Deserialized");
            fin.close();
            oin.close();
          return Dlist;
    }
    
    public String getUname() {
        return Uname;
    }

}
class EligibilityThread extends Thread {
    private User user;

    public EligibilityThread(User user) {
        this.user = user;
    }

    public void run() {
        user.checkEligibility();
        System.out.println("Updated Eligibility for: " + user.getUname());
    }
}
public class Assignment
{
    public static void main(String[] args) throws FileNotFoundException,IOException,ClassNotFoundException
    {
        List<User> UList=new ArrayList<>();
        UList.add(new User("Female",16,"Amala"));
        UList.add(new User("Male",29,"Druv"));
        UList.add(new User("Female",18,"Alia"));
        User obj=new User();
        obj.Serialization(UList);
        System.out.println("---------------------------------");
        List<User> Dlist = obj.Deserialization();
        for(User l:Dlist)
        {
               l.display();
        }
        System.out.println("Updating Eligibility using Threads...");
        List<EligibilityThread> threads = new ArrayList<>();

        for (User user : Dlist) {
            EligibilityThread t = new EligibilityThread(user);
            threads.add(t);
            t.start();
        }

        for (EligibilityThread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Serialization after Updating Eligibility...");
        obj.Serialization(Dlist);

        System.out.println("**********************************");
        List<User> Dlist1=obj.Deserialization();
        System.out.println(("Updated List"));
        for(User u:Dlist1)
        {
            u.display();
        }
    }
}