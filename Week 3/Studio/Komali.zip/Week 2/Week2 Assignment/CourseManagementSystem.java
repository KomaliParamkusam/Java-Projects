import java.math.BigInteger;
import java.util.*;

class Person 
{
    static String AdminName = "Admin";
    static String Password = "TrueId@123";
    static BigInteger Mobnum = new BigInteger("9876543210");
    static int attempt = 3;
    static Scanner sc = new Scanner(System.in);
    static List<Student> students = new ArrayList<>();
    static List<Course> courses = new ArrayList<>();
    static List<Instructor> instructors = new ArrayList<>();
    static HashMap<Integer, Map<String,String>> enrollments = new HashMap<>(); 
    static Map<String,String> assign=new HashMap<>();

    static 
    {
        courses.add(new Course(201,"Java", 10));
        courses.add(new Course(202,"Python", 5));
        courses.add(new Course(203,"Data Science", 6));
    }
    static void availableCourses()
    {
        for(Course c:courses)
        {
            System.out.println(c);
        }
    }
    void LoginSystem()
    {
        System.out.println("1.AdminLogin");
        while (true) 
        { 
                System.out.print("Enter Username:");
                String name=sc.nextLine();
            if(name.equals(AdminName))
            {
                System.out.print("Enter Password: ");
                String Paswrd=sc.nextLine();
                if(!Paswrd.equals(Password))
                {
                    System.out.println("Wrong Password Reset");
                    System.out.println("Enter your mob num");
                    BigInteger Phnno=new BigInteger(sc.nextLine());
                    if(Mobnum.equals(Phnno))
                    {
                        System.out.println("set new password");
                        Password=sc.nextLine();
                        
                    }

                }
                else
                {
                    System.out.println("-------Admin Login Successfully-------");
                    selectOption();
                    break;
                }
            }
            else 
            {
                System.out.println("Incorrect Username. Attempts Remaining: " + (attempt--));
                if (attempt == 0) 
                {
                    System.out.println("Account Blocked.");
                    break;
                }
            }
        }
            
    }
    void selectOption() 
    {
        while (true) 
        {
            System.out.println("1) Add Student");
            System.out.println("2) View Courses ");
            System.out.println("3) Add Course");
            System.out.println("4) Add Instructor");
            System.out.println("5) Assign Instructor");
            System.out.println("6) Enroll Student");
            System.out.println("7) View Reports");
            System.out.println("8) Exit");
            System.out.print("Enter your choice: ");
            int n = sc.nextInt();
            sc.nextLine();

            switch (n) 
            {
                case 1 -> addStudent();
                case 2 -> availableCourses();
                case 3 -> addCourse();
                case 4 -> addInstructor();
                case 5 -> assignInstructor();
                case 6 -> enrollStudent();
                case 7 -> viewReports();
                case 8 -> {
                    System.out.println("Exiting... Goodbye!"); return;
                }
                default -> System.out.println("Invalid choice. Please enter again.");
            }
        }
    }

    void addStudent() 
    {
        System.out.print("Enter Student ID: ");
        int Sid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Student Name: ");
        String Sname = sc.nextLine();
        System.out.print("Enter Student Email: ");
        String Smail = sc.nextLine();
        students.add(new Student(Sid, Sname, Smail));
        enrollments.put(Sid, new HashMap<>());
        System.out.println("Student Added Successfully!");
    }

    void addCourse() 
    {
        System.out.print("Enter Course ID: ");
        int Cid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Course Name: ");
        String Cname = sc.nextLine();
        System.out.print("Enter Course Duration (in months): ");
        int duration = sc.nextInt();
        courses.add(new Course(Cid, Cname, duration));
        System.out.println("Course Added Successfully!");
    }

    void addInstructor() 
    {
        System.out.print("Enter Instructor ID: ");
        int Iid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Instructor Name: ");
        String Iname = sc.nextLine();
        System.out.print("Enter Specialization: ");
        String specialization = sc.nextLine();
        instructors.add(new Instructor(Iid, Iname, specialization));
        System.out.println("Instructor Added Successfully!");
    }

    void assignInstructor() 
    {
        System.out.print("Enter Course ID to assign instructor: ");
        int Cid = sc.nextInt();
        System.out.print("Enter Instructor ID: ");
        int Iid = sc.nextInt();

        Course course = null;
        for (Course c : courses) 
        {
            if (c.getCid() == Cid) 
            {
                course = c;
                break;
            }
        }

        Instructor instructor = null;
        for (Instructor i : instructors) 
        {
            if (i.getIid() == Iid) 
            {
                instructor = i;
                break;
            }
        }

        if (course != null && instructor != null) 
        {
            assign.put("Cource"+course.getCname(),"Instructor"+instructor.getIname());
            System.out.println("Instructor Assigned Successfully");
        } 
        else 
        {
            System.out.println("Invalid Course ID or Instructor ID.");
        }
    }

    void enrollStudent() 
    {
        System.out.print("Enter Student ID: ");
        int Sid = sc.nextInt();
        System.out.print("Enter Course Name: ");
        String CName = sc.next();
        if(!assign.containsKey(CName))
        {
            System.out.println("This Course have no Instructor");
            return;
        }
        if(!enrollments.containsKey(Sid))
        {
            System.out.println("Student with "+Sid+" not registerd");
            return;
        }
        enrollments.get(Sid).put(CName,assign.get(CName));
        System.out.println("--------Student Enrolled Successfully-------");
       
    }

    void viewReports() 
    {
        System.out.println("1 Student Report:");
        System.out.println("2 Course Report:");
        System.out.println("3.Instructor Report:");
        System.out.println("4 Enrollment Report:");
        int n=sc.nextInt();
        sc.nextLine();
        switch (n) {
            case 1 -> 
            {
                for (Student student : students)
                {
                    System.out.println(student);
                }
            }
            case 2 -> 
            {
                for (Course course : courses)
                {
                    System.out.println(course);
                }
            }
            case 3 -> 
            {
                for (Instructor instructor : instructors)
                {
                    System.out.println(instructor);
                }
            }
            default -> 
            {
                for (Map.Entry<Integer, Map<String,String>> entry : enrollments.entrySet())
                {
                    System.out.println("Student ID: " + entry.getKey() + " - Enrolled in Courses: " + entry.getValue());
                }
            }
        }
}
}

class Student 
{
    int Sid;
    String Sname;
    String Smail;

    public Student(int Sid, String Sname, String Smail) 
    {
        this.Sid = Sid;
        this.Sname = Sname;
        this.Smail = Smail;
    }

    public int getSid() {
        return Sid;
    }

    public void setSid(int Sid) {
        this.Sid = Sid;
    }

    public String getSname() {
        return Sname;
    }

    public void setSname(String Sname) {
        this.Sname = Sname;
    }

    public String getSmail() {
        return Smail;
    }

    public void setSmail(String Smail) {
        this.Smail = Smail;
    }
    @Override
    public String toString() 
    {
        return "Student ID: " + Sid + ", Name: " + Sname + ", Email: " + Smail;
    }
}

class Instructor 
{
    int Iid;
    String Iname;
    String specialization;

    Instructor(int Iid, String Iname, String specialization)
    {
        this.Iid = Iid;
        this.Iname = Iname;
        this.specialization = specialization;
    }

    public int getIid() 
    {
        return Iid;
    }

    public void setIid(int Iid) 
    {
        this.Iid = Iid;
    }

    public String getIname() 
    {
        return Iname;
    }

    public void setIname(String Iname) 
    {
        this.Iname = Iname;
    }

    public String getSpecialization()
     {
        return specialization;
    }

    public void setSpecialization(String specialization) 
    {
        this.specialization = specialization;
    }
    @Override
    public String toString() 
    {
        return "Instructor ID: " + Iid + ", Name: " + Iname + ", Specialization: " + specialization;
    }
}

class Course
{
    int Cid;
    String Cname;
    int duration;
    Instructor instructor;

    Course(int Cid, String Cname, int duration) {
        this.Cid = Cid;
        this.Cname = Cname;
        this.duration = duration;
    }
    public int getCid()
     {
        return Cid;
    }

    public void setCid(int Cid) 
    {
        this.Cid = Cid;
    }

    public String getCname() 
    {
        return Cname;
    }

    public void setCname(String Cname) 
    {
        this.Cname = Cname;
    }

    public int getDuration() 
    {
        return duration;
    }

    public void setDuration(int duration) 
    {
        this.duration = duration;
    }
    @Override
    public String toString() 
    {
        return "Course ID: " + Cid + ", Name: " + Cname + ", Duration: " + duration + " months, Instructor: " + (instructor != null ? instructor.Iname : "Not Assigned");
    }
}

public class CourseManagementSystem 
{
    public static void main(String[] args) 
    {
        Person p=new Person();
        p.LoginSystem();
    }
}
