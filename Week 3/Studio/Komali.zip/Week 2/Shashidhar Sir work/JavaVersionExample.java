class JavaVersionExample
{
    public static void main(String[] args)
    {
        var a="Anc";
        System.out.println(((Object)a).getClass().getName());
    }
}