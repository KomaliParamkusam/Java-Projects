
import java.util.Scanner;
class NotEligibleException extends Exception
{

    public NotEligibleException(String message) 
    {
        super(message);
    }
    
}
class ExceptionExample
{
    public void Method(int age) throws NotEligibleException
    {
        try
        {
            // File f=new File("Hello.txt");
            // FileInputStream fi=new FileInputStream(f);

            int val = 10/0;
            System.out.println(val);

        } 
        catch (ArithmeticException e) 
        {
            // if(age<18)
            // {
            //     throw new NotEligibleException("Not eligible to vote");
            // }
            // else
            // {
            //     System.out.println("Exception handled "+e);
            //     System.out.println("You are Eligible to vote");
            // }

            System.out.println(" ArithmeticException EXception ");
            throw new RuntimeException("IO Exception");
        }
        catch(Exception e)
        {
            System.out.println(" Exception block");
        }
    }
    public static void main(String[] args) 
    {
        try (Scanner sc = new Scanner(System.in)) 
        {
            ExceptionExample obj=new ExceptionExample();
            try
            {
             obj.Method(sc.nextInt());
            }
            catch(NotEligibleException e)
            {
                System.out.println(e);
            }
        }
    }

}