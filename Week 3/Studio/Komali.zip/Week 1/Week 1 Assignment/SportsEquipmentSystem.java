import java.util.*;
class OutOfStock extends RuntimeException 
{
    public OutOfStock(String message) 
    {
        super(message);
    }
}
class Equipments 
{
    static Scanner sc = new Scanner(System.in);
    private int id;
    private String name;
    private String brand;
    private double price;
    private int stock;
    static Equipments[] inventory = new Equipments[10]; 
    static int itemCount = 0; 
    public Equipments(String brand, int id, String name, double price, int stock) 
    {
        this.brand = brand;
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }
    static 
    {
        inventory[itemCount++] = new Equipments("Adidas", 101, "Bat", 1500, 20);
        inventory[itemCount++] = new Equipments("Nike", 102, "Ball", 700, 15);
        inventory[itemCount++] = new Equipments("Puma", 103, "Helmet", 1200, 10);

         inventory[itemCount++] = new Equipments("Puma", 201, "Football", 2500.0, 15);
         inventory[itemCount++] = new Equipments("Adidas", 202, "Goalkeeper Gloves", 1800.0, 10);
 
         
         inventory[itemCount++] = new Equipments("Wilson", 301, "Tennis Racket", 3000.0, 12);
         inventory[itemCount++] = new Equipments("Babolat", 302, "Tennis Ball", 400.0, 25);
         System.out.println("Default Inventory:");
         for (int i = 0; i < itemCount; i++)
         {
            if(i==0)
            {
                System.out.println("-------Available Cricket Items in System are--------");
            }
            else if(i==3)
            {
                System.out.println("------Available Football Items in System are------");
            }
            else if(i==5)
            {
                System.out.println("-------Available Tennis Items in System are-----");
            }
             inventory[i].display();
         }
    }


    public int getId() { return id; }
    public String getName() { return name; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    public void display() 
    {
        System.out.println("ID: " + id + ", Name: " + name + ", Brand: " + brand + ", Price: $" + price + ", Stock: " + stock);
    }

    public void addItems() 
    {
        if (itemCount >= inventory.length) 
        {
            System.out.println("Inventory is full. Cannot add more items.");
            return;
        }

        try {
            System.out.println("Enter number of items to add:");
            int num = sc.nextInt();
            sc.nextLine(); 

            for (int i = 0; i < num; i++) 
            {
                if (itemCount >= inventory.length) 
                {
                    System.out.println("Inventory limit reached.");
                    break;
                }

                System.out.print("Enter Brand: ");
                String brand = sc.nextLine();
                System.out.print("Enter ID: ");
                int id = sc.nextInt();
                sc.nextLine();
                System.out.print("Enter Name: ");
                String name = sc.nextLine();
                System.out.print("Enter Price: ");
                double price = sc.nextDouble();
                System.out.print("Enter Stock: ");
                int stock = sc.nextInt();
                sc.nextLine();

                inventory[itemCount++] = new Equipments(brand, id, name, price, stock);
                System.out.println("Item added successfully!");
            }
        } 
        catch (InputMismatchException e) 
        {
            System.out.println(" Invalid input! Please enter the correct data type.");
            sc.nextLine(); 
        }
    }

    public void sellItems() throws OutOfStock {
        try {
            System.out.print("Enter the name of the item to sell: ");
            String itemName = sc.next();
            System.out.print("Enter quantity: ");
            int quantity = sc.nextInt();

            boolean found = false;
            for (int i = 0; i < itemCount; i++)
            {
                if (inventory[i] != null && inventory[i].getName().equalsIgnoreCase(itemName)) {
                    found = true;
                    if (inventory[i].getStock() >= quantity) 
                    {
                        inventory[i].setStock(inventory[i].getStock() - quantity);
                        System.out.println("Sold " + quantity + " of " + itemName);
                    } else 
                    {
                        throw new OutOfStock(" Not enough stock available!");
                    }
                    break;
                }
            }
            if (!found)
            {
                System.out.println(" Item not found in inventory.");
            }
        } catch (InputMismatchException e) 
        {
            System.out.println("Invalid input! Please enter numbers only.");
            sc.nextLine(); 
        }
    }

    public void displayInventory() 
    {
        if (itemCount == 0)
        {
            System.out.println(" No items in inventory.");
            return;
        }
        System.out.println("Available Equipments:");
        for (int i = 0; i < itemCount; i++) 
        {
            if (inventory[i] != null) 
            {
                inventory[i].display();
            }
        }
    }

    public int selectOption() {
        try {
            System.out.println("\n Choose an Operation:");
            System.out.println("1 Add Items");
            System.out.println("2 Sell Items");
            System.out.println("3 Display Inventory");
            System.out.println("4 Return to Main Menu");
            System.out.print("Enter your choice: ");
            return sc.nextInt();
        } 
        catch (InputMismatchException e) 
        {
            System.out.println(" Invalid input! Please enter a valid number.");
            sc.nextLine(); 
            return 0; 
        }
    }

    public void openSystem() {
        while (true) {
            try {
                System.out.println("Welcome to Sports Equipment System");
                System.out.println("1 Cricket");
                System.out.println("2 Football");
                System.out.println("3 Tennis");
                System.out.println("4 Exit");
                System.out.print("Enter your option: ");
                int category = sc.nextInt();
                sc.nextLine();

                if (category == 4) {
                    System.out.println(" Thank you for using the system!");
                    break;
                }

                while (true) {
                    int operation = selectOption();
                    switch (operation) {
                        case 1 -> addItems();
                        case 2 -> sellItems();
                        case 3 -> displayInventory();
                        case 4 -> {
                            System.out.println(" Returning to Main Menu...");
                            break;
                        }
                        default -> System.out.println(" Invalid option, try again.");
                    }
                    if (operation == 4) break;
                }
            } catch (InputMismatchException e) {
                System.out.println(" Invalid input! Please enter a valid number.");
                sc.nextLine();
            }
        }
    }
}

public class SportsEquipmentSystem
{
    
    public static void main(String[] args) 
    {
        Equipments system = new Equipments("Default", 0, "Default", 0, 0);
        system.openSystem();
    }
}
